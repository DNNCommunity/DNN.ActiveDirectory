﻿Namespace DotNetNuke.Authentication.ActiveDirectory
    ''' -------------------------------------------------------------------
    ''' <summary>
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [mhorton]	02/05/2008	Created
    ''' </history>
    ''' -------------------------------------------------------------------
        Public Class ApplicationPool
        ' Fields
        Public DotNetVersion As String = "v2.0.50727"
        Public Name As String = ""
    End Class
End Namespace
